﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CarsApp.Data;
using CarsApp.Models;

namespace CarsApp.Controllers
{
    public class KapcsoloesController : Controller
    {
        private readonly CarsAppContext _context;

        public KapcsoloesController(CarsAppContext context)
        {
            _context = context;
        }

        // GET: Kapcsoloes
        public async Task<IActionResult> Index()
        {
            return View(await _context.Kapcsolo.ToListAsync());
        }

        // GET: Kapcsoloes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kapcsolo = await _context.Kapcsolo
                .FirstOrDefaultAsync(m => m.Id == id);
            if (kapcsolo == null)
            {
                return NotFound();
            }

            return View(kapcsolo);
        }

        // GET: Kapcsoloes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Kapcsoloes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,TulajdonosId,AutoId")] Kapcsolo kapcsolo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(kapcsolo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(kapcsolo);
        }

        // GET: Kapcsoloes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kapcsolo = await _context.Kapcsolo.FindAsync(id);
            if (kapcsolo == null)
            {
                return NotFound();
            }
            return View(kapcsolo);
        }

        // POST: Kapcsoloes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,TulajdonosId,AutoId")] Kapcsolo kapcsolo)
        {
            if (id != kapcsolo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(kapcsolo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!KapcsoloExists(kapcsolo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(kapcsolo);
        }

        // GET: Kapcsoloes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kapcsolo = await _context.Kapcsolo
                .FirstOrDefaultAsync(m => m.Id == id);
            if (kapcsolo == null)
            {
                return NotFound();
            }

            return View(kapcsolo);
        }

        // POST: Kapcsoloes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var kapcsolo = await _context.Kapcsolo.FindAsync(id);
            if (kapcsolo != null)
            {
                _context.Kapcsolo.Remove(kapcsolo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool KapcsoloExists(int id)
        {
            return _context.Kapcsolo.Any(e => e.Id == id);
        }
    }
}
