﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CarsApp.Models;

namespace CarsApp.Data
{
    public class CarsAppContext : DbContext
    {
        public CarsAppContext (DbContextOptions<CarsAppContext> options)
            : base(options)
        {
        }

        public DbSet<CarsApp.Models.Auto> Auto { get; set; } = default!;
        public DbSet<CarsApp.Models.Tulajdonos> Tulajdonos { get; set; } = default!;
        public DbSet<CarsApp.Models.Kapcsolo> Kapcsolo { get; set; } = default!;
    }
}
