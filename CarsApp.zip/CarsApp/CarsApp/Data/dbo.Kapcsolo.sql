﻿CREATE TABLE [dbo].[Kapcsolo] (
    [Id]           INT IDENTITY (1, 1) NOT NULL,
    [TulajdonosId] INT NOT NULL,
    [AutoId]       INT NOT NULL,
    CONSTRAINT [PK_Kapcsolo] PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [FK_Kapcsolo_TulajdonosId] FOREIGN KEY ([TulajdonosId]) REFERENCES [dbo].[Tulajdonos]([Id]), 
    CONSTRAINT [FK_Kapcsolo_AutoId] FOREIGN KEY ([AutoId]) REFERENCES [dbo].[Auto]([Id]),
);

