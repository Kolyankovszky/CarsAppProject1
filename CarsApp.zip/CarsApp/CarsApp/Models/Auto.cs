﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarsApp.Models
{
    public class Auto
    {
        public int Id { get; set; }

        [Display(Name = "Autó márka")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z0-9""'\s-]*$")]
        public string Marka { get; set; }

        [RegularExpression(@"^[A-Z]+[a-zA-Z0-9""'\s-]*$")]
        public string Tipus { get; set; }

        [Display(Name = "Rendszám")]
        [RegularExpression(@"^[A-Z]+[A-Z0-9""'\s-]*$")]
        [StringLength(9, MinimumLength = 7)]
        public string Rendszam { get; set; }

        [Display(Name ="Gyártási Év")]
        [RegularExpression(@"^[0-9]*$")]
        [StringLength(4)]
        public string GyartasEv { get; set;}
    }
}
