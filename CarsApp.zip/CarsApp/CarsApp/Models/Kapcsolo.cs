﻿using System.ComponentModel.DataAnnotations;

namespace CarsApp.Models
{
    public class Kapcsolo
    {
        public int Id { get; set; }
        public int TulajdonosId { get; set; }
        public int AutoId { get; set; }
    }
}
