﻿using CarsApp.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace CarsApp.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new CarsAppContext(

            serviceProvider.GetRequiredService<
                DbContextOptions<CarsAppContext>>())) {
            {
                if (context.Auto.Any())
                {
                    return;
                }
                context.Auto.AddRange(
                    new Auto
                    {
                        Marka = "KIA",
                        Tipus = "Cid",
                        Rendszam = "AA-BB-123",
                        GyartasEv = "2023"
                    },
                    new Auto
                    {
                        Marka = "KIA",
                        Tipus = "Cid",
                        Rendszam = "AA-BB-124",
                        GyartasEv = "2023"
                    },
                    new Auto
                    {
                        Marka = "KIA",
                        Tipus = "Cid",
                        Rendszam = "AA-BB-125",
                        GyartasEv = "2023"
                    },
                    new Auto
                    {
                        Marka = "KIA",
                        Tipus = "Cid",
                        Rendszam = "AA-BB-126",
                        GyartasEv = "2023"
                    },
                    new Auto
                    {
                        Marka = "KIA",
                        Tipus = "Cid",
                        Rendszam = "AA-BB-127",
                        GyartasEv = "2023"
                    }
                    );
                if (context.Tulajdonos.Any())
                {
                    return;
                }
                context.Tulajdonos.AddRange(
                    new Tulajdonos
                    {
                        VezetekNev = "Kis",
                        KeresztNev = "Ádám",
                        SzuletesiDatum = "2000.01.01"
                    },
                    new Tulajdonos
                    {
                        VezetekNev = "Kiss",
                        KeresztNev = "Gábor",
                        SzuletesiDatum = "2002.11.11"
                    },
                    new Tulajdonos
                    {
                        VezetekNev = "Rácz",
                        KeresztNev = "Ádám",
                        SzuletesiDatum = "1980.06.19"
                    }
                    );
                if (context.Kapcsolo.Any())
                {
                    return;
                }
                context.Kapcsolo.AddRange(
                    new Kapcsolo
                    {
                        TulajdonosId = 1,
                        AutoId = 1
                    },
                    new Kapcsolo
                    {
                        TulajdonosId = 1,
                        AutoId = 2
                    },
                    new Kapcsolo {
                        TulajdonosId = 2,
                        AutoId = 3
                    }
                );
                context.SaveChanges();
            }
        }
    }
}

