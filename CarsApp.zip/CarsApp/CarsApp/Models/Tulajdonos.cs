﻿using System.ComponentModel.DataAnnotations;

namespace CarsApp.Models
{
    public class Tulajdonos
    {
        public int Id { get; set; }

        [Display(Name = "Vezetéknév")]
        [RegularExpression(@"^[A-Z]+[a-z]*$")]
        public string VezetekNev { get; set; }

        [Display(Name = "Keresztnév")]
        [RegularExpression(@"^[A-Z]+[a-z]*$")]
        public string KeresztNev { get; set; }

        [Display(Name = "Születési év")]
        [RegularExpression(@"^[0-9]*$")]
        [StringLength(4)]
        public string SzuletesiDatum { get; set; }
    }
}
